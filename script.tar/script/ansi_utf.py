import codecs
import os

path = os.getcwd() + "\\files\\"
path_out = os.getcwd() + "\\files\\result_files\\"
print(path)
print(path_out)
array = []

def primary():
  for filename in os.listdir(path):
    # read from folder
    fp = codecs.open(path+filename, 'r', encoding="utf-8")
    try:
      s = fp.read()
    except UnicodeDecodeError:
      continue

  try:
    #write output file
    with codecs.open(path_out+filename, 'w', encoding = 'cp1251') as file:
      file.write(s)

  except FileNotFoundError:
    print("[ERROR] No file created")
    #
    # # Check what files recoded with an error
    # for filename in os.listdir(path_out):
    #   if os.path.getsize(filename) < 1:
    #     print("Error in: {}".format(filename))

if __name__ == '__main__':
  primary()
